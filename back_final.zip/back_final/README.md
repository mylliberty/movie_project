# Movie App 
Welcome to the Movie App, a simple web application to explore and discover movies. Users can search for movies, view details, and watch trailers. A film, also called a movie or a motion picture, is a series of still photographs on film projected onto a screen using light in rapid succession. This application provies user with a large movie database. In this project the main and key API is OMDb API which helped me to get access to the large database of movies. This helped me to create website which shows a lot of information about movie and also YouTube Data API key is used. This API helped me to provide trialers of the movies from youtube. These two APIs are working as a column of this website. Also Website allows a lot of functionlaties which are will be described below. First of all, user have to succesfull sign in in order to, get access to the functionalties of the website.  
 
# Features 
 > Movie Information: Get real-time movie data including title, runtime description, poster, reatings, actors, genresm etc. 
 > Additional Information: Trailers of the movies. 
 > Admin can add, edit and delete user information accounts 
 > Admin can add, edit and delete certain movies and all this stuff work with database 
 > The added items are shown in main page 
 > # By clicking to the poster, modal window appears, which shows information and trailer added by admin 
 > Log in and registration features are created also 
 > isAdmin value is working 
 > Modal window 
 > Good looking styling(netflix-based colors used) 
 > Unfortunately API does not support russian language and also I could not add the functionality to switch languages 
 > Sliders are shown at main page 
 > API keys are stored separately to add security features 
 
 
# Instructions 
 * Before running type these command in terminal 
 > npm install 
 
 * Account for admin status is 
 > username: daniyar 
 > password: 0404 
 
 * If you want to see the database using VScode, here is the links 
 > mongodb+srv://daniyaradil2004:3872fsFF@cluster0.rqufec3.mongodb.net/assik4
